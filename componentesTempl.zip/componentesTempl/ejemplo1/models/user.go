package models

type User struct {
	Name  string
	Email string
	Age   int
}
