// Internal/Domain/jugador.go
package domain

type Jugador struct {
	ID       string `json:"id"`
	Nombre   string `json:"nombre"`
	Posicion string `json:"posicion"`
}
